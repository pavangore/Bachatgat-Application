from django.contrib import admin
from .models import BachatGatRegistration, MemberRegistration

# Register your models here.
admin.site.register(BachatGatRegistration)
admin.site.register(MemberRegistration)
